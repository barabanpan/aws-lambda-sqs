SQS Lambda Tutorial
===================

![](https://cdn-images-1.medium.com/max/800/1*RNSPfSYQSwaRSBPt5AMXnA.png)

You can find the full tutorial [here](https://epsagon.com/blog/how-to-setup-aws-lambda-with-sqs).
